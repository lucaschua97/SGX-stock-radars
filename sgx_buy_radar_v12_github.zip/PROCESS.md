SGX BUY RADAR V12 — PROCESS GUIDE

1. USER WATCHLIST
- Add/remove stocks from the website.
- The watchlist is stored locally in the browser.
- A custom SGX/Yahoo ticker can be entered with .SI.

2. QUOTE DATA FLOW
Browser -> Cloudflare Worker -> upstream market-data provider -> /api/quotes -> Browser

3. WHAT “QUOTE DATA UPDATED” MEANS
It is the timestamp supplied by the quote API when data was returned.
It does NOT mean the SGX market has just opened.
It does NOT mean BUY/WAIT/HOLD was recalculated.

4. MISSING QUOTES
If a stock shows DATA UNAVAILABLE, the provider/Worker did not return a usable price.
The dashboard must not invent a price or recommendation.
A proper permanent fix requires a server-side fallback provider or a provider entitlement that supports the missing SGX symbols.

5. EVENTS DATA FLOW — NEXT BACKEND LAYER
Browser -> Cloudflare Worker -> corporate-action/event provider -> /api/events -> Browser
Recommended fields:
- earnings/reporting date
- dividend announcement date
- ex-dividend date
- record date
- payment date
- event source
- Events Updated timestamp

6. ANALYSIS DATA FLOW — NEXT BACKEND LAYER
Current price + historical trend + valuation + earnings + dividends + news/risk
-> analysis engine
-> BUY / WAIT / HOLD / AVOID
-> Buy Range + Lock-in Price + confidence + reasons + Analysis Updated timestamp

7. THREE TIMESTAMPS SHOULD ALWAYS BE SEPARATE
- Quote Data Updated
- Events Updated
- Analysis Updated

8. CURRENT V12 IMPLEMENTS
- watchlist management
- add custom ticker
- five themes
- Cloudflare /api/quotes connection
- quote timestamp
- automatic quote refresh
- explicit missing-data handling
- in-app process guide

9. STILL REQUIRES CLOUDflare WORKER BACKEND WORK
- multiple quote-source fallback
- /api/events
- earnings/dividend calendar
- /api/analysis
- dynamic Buy Range
- dynamic Lock-in Price
- BUY/WAIT/HOLD/AVOID scoring
- news/risk integration

10. DEPLOYMENT
- Replace GitHub Pages index.html with V12 index.html.
- Keep API_BASE as https://sgstock.lucaschuaweiliat.workers.dev
- Commit to GitHub.
- Wait for GitHub Pages deployment.
- Hard refresh the site.
